import { createClient } from "@sanity/client";

const options = {
    projectId: process.env.NEXT_PUBLIC_SANITY_PROJECT_ID!,
    dataset: process.env.NEXT_PUBLIC_SANITY_DATASET!,
};

const client = createClient({
    ...options,
    useCdn: process.env.NODE_ENV === "production"
});

export default client;