'use client';
import { useState } from 'react';

import { Configuration, OpenAIApi } from "openai";

const configuration = new Configuration({
    organization: "org-C7OaCIZmVEMregKNk5wDLnRq",
    apiKey: "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",
});
const openai = new OpenAIApi(configuration);

export default function NoteInput() {

    const [num_people, setPeople] = useState('');
    const [date, setDate] = useState('');
    const [num_days, setDays] = useState('');
    const [budget, setBudget] = useState('');
    const [origin, setOrigin] = useState('');
    const [travel_method, setMethod] = useState('');
    const [activities, setActivities] = useState('');
    const [type, setType] = useState('');
    const [generatedText, setGeneratedText] = useState<string>('');

    
  
    const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
      e.preventDefault();

  
    //   const note = {
    //     num_people,
    //     date,
    //     num_days,
    //     budget,
    //     origin,
    //     travel_method,
    //     activities,
    //     type,

    //   };

      const prompt = `you are a specialist in travel recommendations. Based upon the following Please provide 5 detailed recommended vacations with specifics such as attractions, restaurants, etc. in a numbered paragraph form: I will be traveling from ${origin} with ${num_people} people around ${date}. My budget is $${budget} traveling for ${num_days} days and am traveling by ${travel_method}. I like ${activities}, and want a ${type} vacation.`

  
      const completions = async () => {
        const res = await openai.createChatCompletion({
          model: 'gpt-3.5-turbo',
          messages: [
            { role: 'system', content: 'your are a helpful chatbot specializing in travel recommendations'},
            { role: 'user', content: prompt },
          ],
        })
      }
        
  
      console.log(completions.data.choices[0].message);
      const { choices } = completions.data;
  
      if (choices && choices.length > 0) {
        setGeneratedText(choices[0].text || '');
      } else {
        setGeneratedText('Error: No text generated.');
      }
    };
   

  return (
    <div className='gap-4 flex w-1/2 justify-center'>
    <form onSubmit={handleSubmit} className="flex flex-col w-full gap-4 justify-center mx-auto">
      <div className="mb-4">
        <label className="block text-gray-700 font-bold mb-2" htmlFor="title">
          Number of People Traveling:
        </label>
        <input
          className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
          id="num_people"
          type="text"
          placeholder="Enter number of people who will be traveling"
          value={num_people}
          onChange={(e) => setPeople(e.target.value)}
        />
      </div>
      
      <div className="mb-4">
        <label className="block text-gray-700 font-bold mb-2" htmlFor="date">
          Estimated Date of travel:
        </label>
        <input
          className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
          id="date"
          type="date"
          placeholder="Date"
          value={date}
          onChange={(e) => setDate(e.target.value)}
        />
        </div>
        <div className="mb-4">
        <label className="block text-gray-700 font-bold mb-2" htmlFor="num_days">
            How many days would you like to travel?
        </label>
        <input
            className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
            id="num_days"
            type="text"
            placeholder="Number of days"
            value={num_days}
            onChange={(e) => setDays(e.target.value)}
        />
         </div>
         <div className="mb-4">
        <label className="block text-gray-700 font-bold mb-2" htmlFor="budget">
            What is your Travel Budget, Enter in USD.
        </label>
        <input
            className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
            id="budget"
            type="text"
            placeholder="1,500"
            value={budget}
            onChange={(e) => setBudget(e.target.value)}
        />
         </div>
         <div className="mb-4">
        <label className="block text-gray-700 font-bold mb-2" htmlFor="origin">
            Where will you be traveling from?
        </label>
        <input
            className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
            id="origin"
            type="text"
            placeholder="Enter the name of the city you are leaving from"
            value={origin}
            onChange={(e) => setOrigin(e.target.value)}
        />
        <div className="mb-4">
        <label className="block text-gray-700 font-bold mb-2" htmlFor="travel_method">
            What is your preferred method of travel?
        </label>
        <input
            className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
            id="travel_method"
            type="text"
            placeholder="e.g. train, airplane, boat, bus, car, etc."
            value={travel_method}
            onChange={(e) => setMethod(e.target.value)}
        />
         </div>
         </div>
      <div className="mb-4">
        <label className="block text-gray-700 font-bold mb-2" htmlFor="content">
          What type of activites do you enjoy?
        </label>
        <input
          className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
          id="activities"
          placeholder="e.g. fishing, hiking, relaxing on beach, skiing, etc."
          value={activities}
          onChange={(e) => setActivities(e.target.value)}
        />
      </div>
      <div className="mb-4">
        <label className="block text-gray-700 font-bold mb-2" htmlFor="type">
          Type of Vacation?
        </label>
        <input
          className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
          id="type"
          type="text"
          placeholder="e.g. solo travel, family vacation, honeymoon, adventurous, etc."
          value={type}
          onChange={(e) => setType(e.target.value)}
        />
      </div>
      <div className="flex items-center justify-center">
        <button
          className="px-5 py-3 text-sm md:text-base bg-gray-900 text-[#f4e322] flex items-center rounded-full text-center"
          type="submit"
        >
          Generate Results
        </button>
      </div>
    
    </form>
    <div className='flex flex-col w-1/2 gap-4 justify-center mx-auto'>{generatedText && (
        <div>
          <h2>Recommendations:</h2>
          <p>{generatedText}</p>
        </div>
      )}
      </div>
    </div>
  );
}