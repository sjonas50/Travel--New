'use client';

export { PreviewSuspense as default } from "next-sanity/preview";
