'use client';
import { useState } from 'react';

import { Configuration, OpenAIApi } from "openai";

const configuration = new Configuration({
    organization: "org-C7OaCIZmVEMregKNk5wDLnRq",
    apiKey: "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",
});
const openai = new OpenAIApi(configuration);

export default function NoteInput() {

    const [num_people, setPeople] = useState('');
    const [date, setDate] = useState('');
    const [num_days, setDays] = useState('');
    const [budget, setBudget] = useState('');
    const [origin, setOrigin] = useState('');
    const [travel_method, setMethod] = useState('');
    const [activities, setActivities] = useState('');
    const [type, setType] = useState('');
    const [generatedText, setGeneratedText] = useState<string>('');
    const [isLoading, setLoading] = useState(false);
  
    const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
      e.preventDefault();
      setLoading(true);

      const prompt = `you are a specialist in travel recommendations. Based upon the following Please provide 5 detailed recommended vacations related to the dates of travel (for the purpose of seasonality) with specifics such as attractions, restaurants, etc. in a numbered paragraph form (If method of travel is by air, assume that airfare will be 20% higher than expected): I will be traveling from ${origin} with ${num_people} people around ${date}. I need to stay within a budget of $${budget}, including travel, and I can only be gone for a total of ${num_days} days including travel time. I will be traveling to the destination by ${travel_method}. I like ${activities}, and want a ${type} vacation.`

      const completions = await openai.createCompletion({
        model: 'text-davinci-003',
        prompt: prompt,
        temperature: 1,
        max_tokens: 3500,
      });
  
      console.log(completions);
      const { choices } = completions.data;
  
      if (choices && choices.length > 0) {
        setGeneratedText(choices[0].text || '');
      } else {
        setGeneratedText('Error: No text generated.');
      }
      setLoading(false);
    };

  return (

      <div className='container'>
        <div className='gap-4 flex justify-center'>
          <form onSubmit={handleSubmit} className="flex flex-col w-1/2 gap-4 justify-center mb-12 mx-auto">
            <div className="mb-2">
              <label className="block text-gray-700 font-bold" htmlFor="title">
                Number of People Traveling:
              </label>
              <input
                className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                id="num_people"
                type="text"
                placeholder="Enter number of people who will be traveling"
                value={num_people}
                onChange={(e) => setPeople(e.target.value)} />
            </div>

            <div className="mb-2">
              <label className="block text-gray-700 font-bold" htmlFor="date">
                Estimated Date of travel:
              </label>
              <input
                className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                id="date"
                type="date"
                placeholder="Date"
                value={date}
                onChange={(e) => setDate(e.target.value)} />
            </div>
            <div className="mb-2">
              <label className="block text-gray-700 font-bold" htmlFor="num_days">
                How many days would you like to travel?
              </label>
              <input
                className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                id="num_days"
                type="text"
                placeholder="Number of days"
                value={num_days}
                onChange={(e) => setDays(e.target.value)} />
            </div>
            <div className="mb-2">
              <label className="block text-gray-700 font-bold" htmlFor="budget">
                What is your Budget, Enter in USD.
              </label>
              <input
                className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                id="budget"
                type="text"
                placeholder="1,500"
                value={budget}
                onChange={(e) => setBudget(e.target.value)} />
            </div>
            <div className="mb-2">
              <label className="block text-gray-700 font-bold" htmlFor="origin">
                Where will you be traveling from?
              </label>
              <input
                className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                id="origin"
                type="text"
                placeholder="Enter the name of the city you are leaving from"
                value={origin}
                onChange={(e) => setOrigin(e.target.value)} />
            </div>
            <div className="mb-2">
              <label className="block text-gray-700 font-bold" htmlFor="travel_method">
                What is your preferred method of travel?
              </label>
              <select
                className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                id="travel_method"
                value={travel_method}
                onChange={(e) => setMethod(e.target.value)}
              >
                <option value="">Select an option</option>
                <option value="drive">Drive my car</option>
                <option value="airplane">Airplane</option>
                <option value="rental_car">Rental car</option>
                <option value="boat">Boat</option>
                <option value="bus">Bus</option>
                <option value="train">Train</option>
              </select>
            </div>
        <div className="mb-2">
          <label className="block text-gray-700 font-bold" htmlFor="content">
            What type of activites do you enjoy?
          </label>
          <input
            className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
            id="activities"
            placeholder="e.g. fishing, hiking, relaxing on beach, skiing, etc."
            value={activities}
            onChange={(e) => setActivities(e.target.value)} />
        </div>
        <div className="mb-4">
          <label className="block text-gray-700 font-bold" htmlFor="type">
            Type of Vacation?
          </label>
          <input
            className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
            id="type"
            type="text"
            placeholder="e.g. solo travel, family vacation, honeymoon, adventurous, etc."
            value={type}
            onChange={(e) => setType(e.target.value)} />
        </div>
        <div className="flex items-center justify-center">
          <button
            className="px-5 py-3 text-sm md:text-base bg-gray-900 text-[#f4e322] flex items-center rounded-full text-center"
            type="submit"
          >
            {isLoading ? (
              <svg
                className="animate-spin mr-3 h-5 w-5 text-white"
                xmlns="http://www.w3.org/2000/svg"
                fill="none"
                viewBox="0 0 24 24"
              >
                <circle
                  className="opacity-25"
                  cx="12"
                  cy="12"
                  r="10"
                  stroke="currentColor"
                  strokeWidth="4"
                ></circle>
                <path
                  className="opacity-75"
                  fill="currentColor"
                  d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                ></path>
              </svg>
            ) : (
              "Generate Results"
            )}
          </button>
        </div>

      </form>
    <div className='flex w-1/2 gap-4 justify-center mx-auto'>{generatedText && (
      <div>
        <h2>Recommendations:</h2>
        {generatedText.split('\n').map((text, index) => (
          <p key={index} style={{ marginBottom: '1em' }}>{text}</p>
        ))}
      </div>
    )}
      </div>
      </div>
    </div>
  );
}