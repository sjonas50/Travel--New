

export default function loading() {
  return (
    <div>Your Travel Recommendations are loading...</div>
  )
}
