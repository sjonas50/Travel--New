import Image from "next/image";
import Head from "next/head";
import type { NextPage } from "next";
import "../../../styles/globals.css";
import NoteInput from "../../../components/NoteInput";

export default function Home() {
  return (
    <main>
      <div className="mx-auto px-5">
        <h2 className="text-2xl font-bold text-center pt-5 pb-5">
          Kendra's AI Powered Travel Recommendations!
        </h2>
        <p className="text-center pb-5">
          Use our handy dandy AI powered vacation recommendation tool. Input the
          fields below to get 5 recommended vacations.
        </p>
        <p className="text-center pb-5">
          For more recommendations, just click generate results again. Or change
          your parameters for New recommendations!
        </p>
        <div className="gap-1 flex justify-center">
          <NoteInput />
        </div>
      </div>
    </main>
  );
}
