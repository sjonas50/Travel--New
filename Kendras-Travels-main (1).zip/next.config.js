/** @type {import('next').NextConfig} */
module.exports = {
  reactStrictMode: true,
  experimental: {
    appDir: true
  
  },
  experiments: {
    topLevelAwait: true,
  },
  images: {
    domains: ["cdn.sanity.io"],
  },
};
